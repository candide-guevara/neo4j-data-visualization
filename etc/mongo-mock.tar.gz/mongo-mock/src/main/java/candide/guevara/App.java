package candide.guevara;

import java.net.InetSocketAddress;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.ServerAddress;

import de.bwaldvogel.mongo.MongoServer;
import de.bwaldvogel.mongo.backend.memory.MemoryBackend;

public class App {

    public static void main(String[] args) throws Exception {
        InetSocketAddress serverAddress = new InetSocketAddress("localhost", 27017);
        MongoServer server = new MongoServer(new MemoryBackend());
        server.bind(serverAddress);
        System.out.println("Bound to " + serverAddress.toString());
    }

}

